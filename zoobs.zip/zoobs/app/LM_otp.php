<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class LM_otp extends Model
{
    //
}
