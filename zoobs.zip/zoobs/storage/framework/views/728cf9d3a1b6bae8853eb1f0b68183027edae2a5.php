<?php echo $__env->make('header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<main class="app-content">

    <div class="app-title">
        <div class="ships">
            <h1>پرداختی ها<i class="fa fa-th-list"></i></h1>
        </div>
    </div>
    <div class="row">
        <div class="col-md-12">
            <div class="tile">
                <div class="tile-body">
                    <div class="table-responsive">
                        <table class="table table-hover table-bordered" id="sampleTable">
                            <thead>
                            <tr>
                                <th>آیدی</th>
                                <th>کاربری</th>
                                <th>وضعیت</th>
                                <th>مقدار</th>
                                <th>توضیحات</th>
                                <th>شماره پیگیری</th>
                                <th>تاریخ</th>
                                <th>زمان</th>
                            </tr>
                            </thead>
                            <tbody>

                            <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                                <tr>
                                    <td><?php echo e($row->id); ?></td>
                                    <td><?php echo e($row->user_id); ?></td>
                                    <td><?php echo e($row->status); ?></td>
                                    <td><?php echo e($row->mount); ?></td>
                                    <td><?php echo e($row->desc); ?></td>
                                    <td><?php echo e($row->RefID); ?></td>
                                    <td><?php echo e($row->date); ?></td>
                                    <td><?php echo e($row->time); ?></td>

                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>
</main>

<?php echo $__env->make('footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<script type="text/javascript" src="<?php echo e(asset('include/panel/js/plugins/jquery.dataTables.min.js')); ?>" ></script>
<script type="text/javascript" src="<?php echo e(asset('include/panel/js/plugins/dataTables.bootstrap.min.js')); ?>"></script>
<script type="text/javascript">$('#sampleTable').DataTable();</script>

<?php /**PATH /home/zobs/zoobs/resources/views/panelpayment.blade.php ENDPATH**/ ?>