<?php echo $__env->make('header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <main class="app-content">
        <div class="app-title">
            <div class="ships">
                <h1>تنظیمات <i class="fa fa-th-list"></i></h1>
            </div>

        </div>

        <div class="row">
            <div class="col-md-12">
                <div class="tile">
                    <form class="dispaly-contents" id="add_chat" action="api/panel" method="post">
                        <div class="tile-body">
                            <div class="form-group">
                                <label for="exampleTextarea">درباره ما</label>
                                <textarea class="form-control" id="mytextarea" name="about" rows="15"><?php echo e($about); ?></textarea>
                            </div>
                        </div>

                        <div class="tile-body">
                            <div class="form-group">
                                <label for="exampleTextarea">حریم خصوصی</label>
                                <textarea class="form-control" id="mytextarea1" name="privacy" rows="5"><?php echo $privacy; ?></textarea>
                            </div>
                        </div>
                        <div class="tile-body">
                            <div class="form-group">
                                <label for="exampleTextarea">قوانین و مقررات</label>
                                <textarea class="form-control" id="mytextarea2" name="law" rows="15"><?php echo e($law); ?></textarea>
                            </div>
                        </div>
                        <input type="hidden"  name="action" value="update_setting">

                        <button class="btn btn-primary" name="reg" type="submit"><i class="fa fa-fw fa-lg fa-check-circle"></i>ثبت</button>

                    </form>
                </div>
            </div>
        </div>
    </main>

<?php echo $__env->make('footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<script src="<?php echo e(asset('include/panel/js/tinymce/tinymce.min.js')); ?>"></script>

<script>


    tinymce.init({
        selector: '#mytextarea',
        language: "fa_IR" //
    });
tinymce.init({
        selector: '#mytextarea1',
        language: "fa_IR" //
    });
tinymce.init({
        selector: '#mytextarea2',
        language: "fa_IR" //
    });


</script>
<script>
    // $("form#add_chat").submit(function(e) {
    //
    //     var x = document.getElementById('mytextarea').innerHTML;
    //
    //     console.log(x);
    //
    //     e.preventDefault();
    //     var formData = new FormData(this);
    //     $.ajax({
    //         url: 'api/panel',
    //         type: 'POST',
    //         data: formData,
    //         success: function (data) {
    //             // alert(data)
    //             const res=JSON.parse(data);
    //
    //             if (res.status=='ok' || res.status=='nook'){
    //                 swal({
    //                     title: "عملیات با موفقیت انجام شد",
    //                     text: "تصمیم بعدی شما چیست؟",
    //                     type: "success",
    //                     confirmButtonText: "ادامه",
    //                     confirmButtonColor: '#002bff',
    //                     closeOnConfirm: false,
    //                     closeOnCancel: false
    //                 }, function(isConfirm) {
    //                     if (isConfirm) {
    //                         location.reload();
    //                     }
    //                 });
    //             }
    //             else {
    //
    //                 swal("ارور پایگاه داده", "مشکلی به وجود آمده", "error");
    //             }
    //         },
    //         error : function() {
    //             swal("ارور سیستمی", "مشکلی به وجود آمده", "error");
    //         },
    //         cache: false,
    //         contentType: false,
    //         processData: false
    //     });
    // });

</script>
<?php /**PATH /home/zobs/zoobs/resources/views/setting.blade.php ENDPATH**/ ?>