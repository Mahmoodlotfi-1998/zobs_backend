<?php echo $__env->make('header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<main class="app-content">

    <div class="app-title">
        <div class="ships">
            <h1>اشتراک ها<i class="fa fa-th-list"></i></h1>
        </div>
        <p><a class="btn btn-info icon-btn" onclick="open_create_user();">اضافه کردن<i style="margin-left: 10px;" class="fa fa-plus"></i></a></p>
    </div>

    <div class="row" style="display: none;" id="insert_dcat">
        <div class="col-md-12">
            <div class="tile">
                <div class="row">
                    <form class="dispaly-contents" id="add_user" method="post">
                        <div class="col-lg-6 float-right" style="float: right;">
                            <div class="form-group">
                                <br>
                                <button class="btn btn-info icon-btn" name="inc">افزودن<i style="margin-left: 10px;" class="fa fa-plus"></i></button>
                                <br>
                                <br>
                                <div class="btn btn-danger"  onclick="close_create_user();">لغو</div>
                            </div>
                        </div>
                        <div class="col-lg-6">
                            <div class="form-group">
                                <label for="exampleInputPassword1">شماره همراه</label>
                                <input class="form-control" name="phone" id="exampleInputPassword1" type="number" maxlength="11">
                                <label for="exampleInputPassword1">نام</label>
                                <input class="form-control" name="first_name" id="exampleInputPassword1" type="text">
                                <label for="exampleInputPassword1">نام خانوادگی</label>
                                <input class="form-control" name="last_name" id="exampleInputPassword1" type="text">

                                <input class="form-control" name="action" value="add_user" id="exampleInputPassword1" type="hidden" >
                                <label for="exampleInputPassword1">نقش</label>
                                <select class="form-control type" id="exampleSelect2" name="type">
                                    <option value="admin" >مدیریت</option>
                                    <option  value="helper">معاونت</option>
                                    <option value="agent">نماینده</option>
                                    <option value="norm">عادی</option>
                                    <option value="0">بدون نقش</option>
                                </select>
                            </div>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
    <div class="row" style="display: none;" id="edite_dcat">
        <div class="col-md-12">
            <div class="tile">
                <div class="row">
                    <form class="dispaly-contents" id="edit_user" method="post">
                        <div class="col-lg-6 float-right" style="float: right;">
                            <div class="form-group">
                                <br>
                                <button class="btn btn-info icon-btn" name="inc">ویرایش<i style="margin-left: 10px;" class="fa fa-plus"></i></button>
                                <br>
                                <br>
                                <div class="btn btn-danger"  onclick="close_edit_user();">لغو</div>
                            </div>
                        </div>
                        <div class="col-lg-6">
                            <div class="form-group">
                                <label for="exampleInputPassword1">شماره همراه</label>
                                <input class="form-control" name="phone_edite" id="phone_edite" type="text" maxlength="11">
                                <input class="form-control" name="action" value="change_user_rules" type="hidden" >
                                <input class="form-control" name="user_id" value="" id="user_id" type="hidden" >
                                <label for="exampleInputPassword1">نقش</label>
                                <select class="form-control type" name="type_edit">
                                    <option value="admin" >مدیریت</option>
                                    <option  value="helper">معاونت</option>
                                    <option value="agent">نماینده</option>
                                    <option value="norm">عادی</option>
                                    <option value="0">بدون نقش</option>
                                </select>
                            </div>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
    <div class="row">
        <div class="col-md-12">
            <div class="tile">
                <div class="tile-body">
                    <div class="table-responsive">
                        <table class="table table-hover table-bordered" id="sampleTable">
                            <thead>
                            <tr>
                                <th>کاربری</th>
                                <th>تعداد</th>
                                <th>عملیات</th>
                            </tr>
                            </thead>
                            <tbody>

                            <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                                <tr>
                                    <td><?php echo e($row->user_id); ?></td>
                                    <td><?php echo e($row->user_count); ?></td>

                                    <td>
                                        <a class=" btn btn-info" href="chat.php?user_id=<?php echo e($row->user_id); ?>">نمایش</a>
                                    </td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>
</main>

<?php echo $__env->make('footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<script type="text/javascript" src="<?php echo e(asset('include/panel/js/plugins/jquery.dataTables.min.js')); ?>" ></script>
<script type="text/javascript" src="<?php echo e(asset('include/panel/js/plugins/dataTables.bootstrap.min.js')); ?>"></script>
<script type="text/javascript">$('#sampleTable').DataTable();</script>

<?php /**PATH /home/zobs/zoobs/resources/views/tickets.blade.php ENDPATH**/ ?>