<?php echo $__env->make('header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<main class="app-content">

    <div class="col-md-12">
      <div class="tile">
        <div class="messanger">
          <div class="messages">

              <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                  <div class="message <?php if($row->sender ==1): ?> me <?php endif; ?>">
                      <p class="info"><?php echo e($row->description); ?></p>
                  </div>

              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

          </div>
          <div class="sender">
              <form class="dispaly-contents" id="add_chat" method="post">
                  <input type="text" name="description" style="direction: rtl;text-align: right;" placeholder="پیام">
                  <input type="hidden"  name="action" value="add_ticket">
                  <input type="hidden" name="user_id" value="<?php echo e($user_id); ?>">
                  <button class="btn btn-primary" type="submit"><i class="fa fa-lg fa-fw fa-paper-plane"></i></button>
              </form>
            </div>
        </div>
      </div>
    </div>

</main>
<?php echo $__env->make('footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<script>
    $("form#add_chat").submit(function(e) {

        e.preventDefault();
        var formData = new FormData(this);
        $.ajax({
            url: 'api/panel',
            type: 'POST',
            data: formData,
            success: function (data) {
                const res=JSON.parse(data);

                if (res.status=='ok'){
                    swal({
                        title: "عملیات با موفقیت انجام شد",
                        text: "تصمیم بعدی شما چیست؟",
                        type: "success",
                        confirmButtonText: "ادامه",
                        confirmButtonColor: '#002bff',
                        closeOnConfirm: false,
                        closeOnCancel: false
                    }, function(isConfirm) {
                        if (isConfirm) {
                            location.reload();
                        }
                    });
                }
                else {

                    swal("ارور پایگاه داده", "مشکلی به وجود آمده", "error");
                }
            },
            error : function() {
                swal("ارور سیستمی", "مشکلی به وجود آمده", "error");
            },
            cache: false,
            contentType: false,
            processData: false
        });
    });

</script>
<?php /**PATH /home/zobs/zoobs/resources/views/chat.blade.php ENDPATH**/ ?>