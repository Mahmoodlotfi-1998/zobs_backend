<!DOCTYPE html>
<html lang="en">

<head>

    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="">
    <meta name="author" content="">

    <title>حریم خصوصی زوبس</title>

    <link href="<?php echo e(asset('include/css/main.css')); ?>" rel="stylesheet">

</head>

<body class="body_pay">
<div class="color_opacity" style="float: right;width: 100%;">


    <div class="content" style="direction: rtl;">

        <?php echo $data ?>
    </div>

</div>
</body>
</html>
<?php /**PATH /home/zobs/zoobs/resources/views/privacy.blade.php ENDPATH**/ ?>