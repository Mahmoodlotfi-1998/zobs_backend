<script src="<?php echo e(asset('include/panel/js/jquery-3.3.1.min.js')); ?>"></script>
<script src="<?php echo e(asset('include/panel/js/popper.min.js')); ?>"></script>
<script src="<?php echo e(asset('include/panel/js/bootstrap.min.js')); ?>"></script>
<script src="<?php echo e(asset('include/panel/js/main.js')); ?>"></script>
<script src="<?php echo e(asset('include/panel/js/plugins/pace.min.js')); ?>"></script>
<script src="<?php echo e(asset('include/panel/js/plugins/chart.js')); ?>"></script>
<script src="<?php echo e(asset('include/panel/js/plugins/sweetalert.min.js')); ?>"></script>
</body>

</html>
<?php /**PATH /home/zobs/zoobs/resources/views/footer.blade.php ENDPATH**/ ?>