<?php echo $__env->make('header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<main class="app-content">

    <div class="app-title">
        <div class="ships">
            <h1>دسته ها<i class="fa fa-th-list"></i></h1>
        </div>
    </div>

    <div class="row">
        <div class="col-md-12">
            <div class="tile">
                <div class="tile-body">
                    <div class="table-responsive">
                        <table class="table table-hover table-bordered" id="sampleTable">
                            <thead>
                            <tr>
                                <th>آیدی</th>
                                <th>عنوان</th>
                                <th>تصویر</th>
                                <th>عملیات</th>
                            </tr>
                            </thead>
                            <tbody>

                            <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                                <tr>
                                    <td><?php echo e($row->id); ?></td>
                                    <td><?php echo e($row->title); ?></td>
                                    <td class="row_image"><img src="<?php echo e($row->pic); ?> "></td>
                                    <td>
                                        <a class=" btn btn-info" href="dcategory.php?id=<?php echo e($row->id); ?>">ویرایش زیر دسته ها</a>
                                    </td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>
</main>

<?php echo $__env->make('footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<script type="text/javascript" src="<?php echo e(asset('include/panel/js/plugins/jquery.dataTables.min.js')); ?>" ></script>
<script type="text/javascript" src="<?php echo e(asset('include/panel/js/plugins/dataTables.bootstrap.min.js')); ?>"></script>
<script type="text/javascript">$('#sampleTable').DataTable();</script>

<?php /**PATH /home/zobs/zoobs/resources/views/categorys.blade.php ENDPATH**/ ?>